import { LightningElement } from 'lwc';

export default class exportSettngs extends LightningElement {}